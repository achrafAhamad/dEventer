package es.achraf.deventer.restApi;

public final class RestApiConstants {
    public static final String ROOT_URL = "https://arcane-bastion-84461.herokuapp.com/";
    public static final String KEY_POST_ID_TOKEN = "token-device/";
    public static final String KEY_TOQUE_ANIMAL = "toque-animal/{id}/{mensaje}/";
    public static String TOKEN = "";
}
